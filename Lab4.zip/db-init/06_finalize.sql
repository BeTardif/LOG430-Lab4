-- SQL Finalize

ALTER TABLE orders ENABLE KEYS;
ALTER TABLE order_items ENABLE KEYS;

SET FOREIGN_KEY_CHECKS=1;
SET autocommit=1;
COMMIT;

OPTIMIZE TABLE users;
OPTIMIZE TABLE products;
OPTIMIZE TABLE orders;
OPTIMIZE TABLE order_items;
OPTIMIZE TABLE stocks;

ANALYZE TABLE users;
ANALYZE TABLE products;
ANALYZE TABLE orders;
ANALYZE TABLE order_items;
ANALYZE TABLE stocks;
