-- SQL Cleanup and Setup

SET FOREIGN_KEY_CHECKS=0;
SET autocommit=0;

ALTER TABLE orders DISABLE KEYS;
ALTER TABLE order_items DISABLE KEYS;
